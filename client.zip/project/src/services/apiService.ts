// Mock API service for demonstration
// In production, replace these with actual API calls

const API_BASE_URL = 'http://localhost:8000';

const simulateApiCall = (data: any, delay: number = 1000) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate some failures for demo purposes
      if (Math.random() < 0.1) { // 10% chance of failure
        reject(new Error('API Error'));
      } else {
        resolve(data);
      }
    }, delay);
  });
};

export const apiService = {
  async addCustomer(data: { name: string; address: string }) {
    console.log('Adding customer:', data);
    // In production: return fetch(`${API_BASE_URL}/add_customer`, { method: 'POST', body: JSON.stringify(data) });
    return simulateApiCall({ success: true, crn: `CRN${Date.now()}` });
  },

  async deleteCustomer(data: { crn: string }) {
    console.log('Deleting customer:', data);
    // In production: return fetch(`${API_BASE_URL}/delete_customer`, { method: 'POST', body: JSON.stringify(data) });
    return simulateApiCall({ success: true });
  },

  async addAccount(data: { crn: string; initialBalance: string }) {
    console.log('Adding account:', data);
    // In production: return fetch(`${API_BASE_URL}/add_account`, { method: 'POST', body: JSON.stringify(data) });
    return simulateApiCall({ success: true, accountNumber: `ACC${Date.now()}` });
  },

  async addAddress(data: { address: string }) {
    console.log('Adding address:', data);
    // In production: return fetch(`${API_BASE_URL}/add_address`, { method: 'POST', body: JSON.stringify(data) });
    return simulateApiCall({ success: true });
  },

  async makeTransaction(data: { senderAccountId: string; recipientAccountId: string; amount: string }) {
    console.log('Making transaction:', data);
    // In production: return fetch(`${API_BASE_URL}/make_transaction`, { method: 'POST', body: JSON.stringify(data) });
    return simulateApiCall({ success: true, transactionId: `TXN${Date.now()}` });
  },

  async getCustomerAccounts(crn: string) {
    console.log('Getting customer accounts for CRN:', crn);
    // In production: return fetch(`${API_BASE_URL}/customer/${crn}/accounts`).then(res => res.json());
    return simulateApiCall([
      { accountNumber: `ACC${crn}001` },
      { accountNumber: `ACC${crn}002` },
      { accountNumber: `ACC${crn}003` },
    ]);
  },

  async getAccountBalance(accountNumber: string) {
    console.log('Getting balance for account:', accountNumber);
    // In production: return fetch(`${API_BASE_URL}/account/${accountNumber}/balance`).then(res => res.json());
    return simulateApiCall({ 
      balance: Math.floor(Math.random() * 10000) + Math.random(),
      accountNumber 
    });
  },
};